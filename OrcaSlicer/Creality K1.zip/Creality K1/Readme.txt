#############################
INSTALLATION (ENGLISH)
#############################

1. Add a printer by selecting "Generic Klipper Printer".

2. Click on "File" -> "Import" -> "Import configurations..." then import the printer located in the "Printer" folder.

3. Click on "File" -> "Import" -> "Import configurations..." then import all the filaments located in the "Filaments" folder.

4. Click on "File" -> "Import" -> "Import configurations..." then import all the profiles located in the "Profiles" folder.

5. Click on the icon for editing printer presets then click on "Define ..." of the "Printable area" parameter then load the file "Texture_with_Calibration.png" or "Texture_without_Calibration.png" (the one you want) in the "Texture" box and the file " Build_Plate.stl" in the "Model" box located in the "Textures" folder.


#############################
INSTALLATION (FRANÇAIS)
#############################

1. Ajoutez une imprimante en sélectionnant "Generic Klipper Printer".

2. Cliquez sur "Fichier" -> "Importer" -> "Importer des configurations..." puis importez l'imprimante présente dans le dossier "Printer".

3. Cliquez sur "Fichier" -> "Importer" -> "Importer des configurations..." puis importez l'ensemble des filaments présents dans le dossier "Filaments".

4. Cliquez sur "Fichier" -> "Importer" -> "Importer des configurations..." puis importez l'ensemble des profils présents dans le dossier "Profiles".

5. Cliquez sur l'icône d'édition des préréglages de l'imprimante puis cliquez sur "Définir ..." du paramètre "Zone imprimable" puis charger le fichier "Texture_with_Calibration.png" ou "Texture_without_Calibration.png" (celui que vous désirez) dans l'encadré "Texture" et le fichier "Build_Plate.stl" dans l'encadré "Modèle" présents dans le dossier "Textures".